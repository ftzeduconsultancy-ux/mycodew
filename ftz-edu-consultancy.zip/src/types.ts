export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'agent' | 'student';
  status: 'pending' | 'approved';
  avatarUrl?: string;
  countries?: string[]; // Countries the agent wants to work on / select
  createdAt: string;
  password?: string;
  studentId?: string; // Auto-generated unique student ID (STU-XXXXXX)
}

export interface Country {
  id: string;
  name: string;
  imageUrl: string;
  description: string;
}

export interface Scholarship {
  isFullyFunded: boolean;
  title: string;
  description: string;
  amount: string;
  summerDeadline?: string;
  fallDeadline?: string;
  adminComment?: string;
}

export interface GlobalScholarship {
  id: string;
  title: string;
  description: string;
  amount: string;
  isFullyFunded: boolean;
  countryId: string; // Mandatory country reference
  universityId?: string; // Optional partner university reference
  universityName?: string; // Optional custom name if not a partner university
  imageUrl?: string; // Beautiful custom image URL
  createdAt?: string;
  summerDeadline?: string;
  fallDeadline?: string;
  adminComment?: string;
}

export interface University {
  id: string;
  name: string;
  countryId: string;
  imageUrl: string;
  programs: string[]; // e.g. ["Bachelor", "Master", "PhD"]
  subjects: string[]; // e.g. ["Computer Science", "Business Admin", "Mechanical Engineering"]
  scholarship?: Scholarship;
  summerDeadline?: string;
  fallDeadline?: string;
  adminComment?: string;
}

export interface DocumentUpload {
  name: string;
  url: string; // can be data URL or server path
  size: string;
  uploadedAt: string;
}

export interface ApplicationNote {
  id: string;
  author: string;
  authorRole: string;
  text: string;
  createdAt: string;
}

export interface Application {
  id: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  universityId: string;
  universityName: string;
  countryId: string;
  countryName: string;
  program: string;
  passportNumber: string;
  documents: DocumentUpload[];
  status: string; // e.g. 'Request to Agency', 'Approved by Agency', 'Application Submitted', etc., or custom status
  portalScreenshot?: string; // Optional Base64 or Image URL upload of the portal state
  notes: ApplicationNote[];
  agentId?: string; // assigned agent id
  createdAt: string;
}

export interface Staff {
  id: string;
  name: string;
  role: string;
  bio: string;
  imageUrl: string;
}

export interface StorageConfig {
  destinationLink: string;
  provider: 'Google Drive' | 'Firebase Storage' | 'Local Folders' | 'Custom';
}

export interface Branding {
  name: string;
  logoText: string;
  logoUrl?: string;
  primaryColor: string;
  emailContact: string;
  emailContact2?: string;
  welcomeTitle?: string;
  welcomeLetter?: string;
  statsStudents?: string;
  statsUniversities?: string;
  statsScholarships?: string;
  statsVisaRate?: string;
}

export interface SystemSettings {
  disableStudentLogin: boolean;
  disableStudentRegister: boolean;
  disableAgentLogin: boolean;
  disableAgentRegister: boolean;
}

export interface MessageAttachment {
  name: string;
  url: string;
  size: string;
  type: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
  seen: boolean;
  seenAt?: string;
  attachment?: MessageAttachment;
}

export interface Conversation {
  id: string;
  participants: string[]; // User IDs
  lastMessageText?: string;
  lastMessageTimestamp?: string;
  createdAt: string;
}

export interface ChatNotification {
  id: string;
  recipientId: string;
  senderId: string;
  senderName: string;
  type: 'message';
  text: string;
  read: boolean;
  createdAt: string;
}
