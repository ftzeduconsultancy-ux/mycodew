import { User, Branding } from "../types";
import { LogOut, Globe, Shield, UserCheck, GraduationCap, FileText, Settings, HeartHandshake, MessagesSquare } from "lucide-react";

interface HeaderProps {
  user: User | null;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  branding: Branding;
  unreadCount: number;
  onOpenChat: () => void;
}

export default function Header({ user, onLogout, activeTab, setActiveTab, branding, unreadCount, onOpenChat }: HeaderProps) {
  // Determine role styling/badges
  const getBadgeColor = (role?: string) => {
    switch (role) {
      case "admin":
        return "bg-amber-100 text-amber-800 border-amber-300";
      case "agent":
        return "bg-indigo-100 text-indigo-800 border-indigo-300";
      default:
        return "bg-emerald-100 text-emerald-800 border-emerald-300";
    }
  };

  return (
    <header className="bg-white border-b border-gray-100 sticky top-0 z-50 shadow-xs" id="app-header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          {/* Logo Brand Panel */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab("home")} id="brand-logo-panel">
            {branding.logoUrl ? (
              <img
                src={branding.logoUrl}
                alt={branding.name}
                className="w-10 h-10 object-contain rounded-xl border border-gray-200"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold shadow-md shadow-indigo-100 border border-indigo-500">
                {branding.logoText || "FTZ"}
              </div>
            )}
            <div>
              <span className="text-xl font-bold tracking-tight text-gray-900 border-b-2 border-indigo-500 pb-0.5">
                {branding.name || "FTZ EDU CONSULTANCY"}
              </span>
              <span className="hidden sm:block text-[10px] text-gray-500 font-medium tracking-widest uppercase">
                Consultancy Portal
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex space-x-1" id="desktop-nav">
            <button
              onClick={() => setActiveTab("home")}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === "home" || activeTab === "country-universities"
                  ? "bg-indigo-50 text-indigo-600"
                  : "text-gray-600 hover:text-gray-950 hover:bg-gray-50"
              }`}
              id="nav-home"
            >
              <span className="flex items-center gap-1.5"><Globe className="w-4 h-4" /> Countries & Universities</span>
            </button>
            <button
              onClick={() => setActiveTab("scholarships")}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === "scholarships"
                  ? "bg-indigo-50 text-indigo-600"
                  : "text-gray-600 hover:text-gray-950 hover:bg-gray-50"
              }`}
              id="nav-scholarships"
            >
              <span className="flex items-center gap-1.5"><GraduationCap className="w-4 h-4" /> Scholarships</span>
            </button>
            <button
              onClick={() => setActiveTab("about")}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === "about"
                  ? "bg-indigo-50 text-indigo-600"
                  : "text-gray-600 hover:text-gray-950 hover:bg-gray-50"
              }`}
              id="nav-about"
            >
              <span className="flex items-center gap-1.5"><HeartHandshake className="w-4 h-4" /> About Us Staff</span>
            </button>
            {user && user.status === "approved" && (
              <button
                onClick={() => {
                  if (user.role === "admin") setActiveTab("admin-panel");
                  else if (user.role === "agent") setActiveTab("agent-panel");
                  else setActiveTab("student-panel");
                }}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors border ${
                  ["admin-panel", "agent-panel", "student-panel"].includes(activeTab)
                    ? "bg-indigo-600 text-white border-indigo-700"
                    : "border-indigo-200 text-indigo-600 hover:bg-indigo-50"
                }`}
                id="nav-dashboard"
              >
                <span className="flex items-center gap-1.5 font-semibold">
                  {user.role === "admin" && <Shield className="w-4 h-4" />}
                  {user.role === "agent" && <UserCheck className="w-4 h-4" />}
                  {user.role === "student" && <FileText className="w-4 h-4" />}
                  My Dashboard
                </span>
              </button>
            )}
          </nav>

          {/* User Section / Action buttons */}
          <div className="flex items-center space-x-4" id="header-user-section">
            {user && (
              <button
                onClick={onOpenChat}
                className="relative p-2.5 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                title="Open Messenger"
              >
                <MessagesSquare className="w-5 h-5 text-indigo-600" />
                <span className="hidden sm:inline text-xs font-bold text-gray-750">Chats</span>
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white font-extrabold text-[9px] w-4.5 h-4.5 rounded-full flex items-center justify-center border border-white animate-bounce shadow-sm">
                    {unreadCount}
                  </span>
                )}
              </button>
            )}
            {user ? (
              <div className="flex items-center space-x-3 bg-gray-50 p-1.5 pr-3 rounded-full border border-gray-100">
                <img
                  src={user.avatarUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200"}
                  alt={user.name}
                  className="w-8 h-8 rounded-full object-cover border border-indigo-200"
                  referrerPolicy="no-referrer"
                />
                <div className="hidden sm:block text-left">
                  <div className="text-xs font-semibold text-gray-900 leading-tight truncate max-w-[120px]">{user.name}</div>
                  <span className={`inline-block text-[9px] px-1.5 py-0.2 rounded-full border font-bold uppercase ${getBadgeColor(user.role)}`}>
                    {user.role}
                  </span>
                </div>
                <button
                  onClick={onLogout}
                  className="p-1 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"
                  title="Logout"
                  id="header-logout-btn"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setActiveTab("login")}
                className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-all shadow-md shadow-indigo-100 hover:shadow-indigo-200"
                id="header-login-action"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
