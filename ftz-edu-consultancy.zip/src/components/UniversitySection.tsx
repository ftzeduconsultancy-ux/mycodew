import React, { useState, useEffect } from "react";
import { University, Country, User } from "../types";
import { Search, GraduationCap, ArrowUpRight, Award, Plus, Trash2, Edit3, BookOpen, Target, Sparkles, X, Check, Calendar, Clock, MessageSquare } from "lucide-react";

export const getCountdown = (dateStr?: string) => {
  if (!dateStr) return null;
  const deadline = new Date(dateStr);
  if (isNaN(deadline.getTime())) return null;
  
  const now = new Date();
  const dDate = new Date(deadline.getFullYear(), deadline.getMonth(), deadline.getDate());
  const dNow = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const diffTime = dDate.getTime() - dNow.getTime();
  if (diffTime < 0) {
    return { days: 0, text: "Closed" };
  }
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  if (diffDays === 0) {
    return { days: 0, text: "Closes today!" };
  }
  if (diffDays === 1) {
    return { days: 1, text: "1 day left!" };
  }
  return { days: diffDays, text: `${diffDays} days left` };
};

export const formatDate = (dateStr?: string) => {
  if (!dateStr) return "";
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return dateStr;
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
};

interface UniversitySectionProps {
  universities: University[];
  countries: Country[];
  selectedCountryId: string | null;
  user: User | null;
  onApply: (uni: University) => void;
  onAddUniversity: (newUni: Omit<University, "id">) => Promise<void>;
  onUpdateUniversity: (id: string, updated: Partial<University>) => Promise<void>;
  onDeleteUniversity: (id: string) => Promise<void>;
}

export default function UniversitySection({
  universities,
  countries,
  selectedCountryId,
  user,
  onApply,
  onAddUniversity,
  onUpdateUniversity,
  onDeleteUniversity,
}: UniversitySectionProps) {
  const isAdmin = user?.role === "admin";
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProgramFilter, setSelectedProgramFilter] = useState("All");
  const [selectedCountryFilter, setSelectedCountryFilter] = useState<string>("All");
  const [selectedUniversityFilter, setSelectedUniversityFilter] = useState<string>("All");

  useEffect(() => {
    setSelectedUniversityFilter("All");
  }, [selectedCountryFilter]);

  useEffect(() => {
    if (selectedCountryId) {
      setSelectedCountryFilter(selectedCountryId);
    } else {
      setSelectedCountryFilter("All");
    }
  }, [selectedCountryId]);

  // Managing form states for Admin
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [formName, setFormName] = useState("");
  const [formCountryId, setFormCountryId] = useState("");
  const [formImageUrl, setFormImageUrl] = useState("");
  const [formPrograms, setFormPrograms] = useState(""); // comma separated
  const [formSubjects, setFormSubjects] = useState(""); // comma separated
  const [formSchFully, setFormSchFully] = useState(false);
  const [formSchTitle, setFormSchTitle] = useState("");
  const [formSchDesc, setFormSchDesc] = useState("");
  const [formSchAmount, setFormSchAmount] = useState("");
  const [formSummerDeadline, setFormSummerDeadline] = useState("");
  const [formFallDeadline, setFormFallDeadline] = useState("");
  const [formAdminComment, setFormAdminComment] = useState("");

  const handleOpenAdd = () => {
    setFormName("");
    setFormCountryId(selectedCountryId || countries[0]?.id || "");
    setFormImageUrl("https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=800");
    setFormPrograms("Bachelor, Master, PhD");
    setFormSubjects("Computer Science, Business Administration, Data Science");
    setFormSchFully(false);
    setFormSchTitle("");
    setFormSchDesc("");
    setFormSchAmount("");
    setFormSummerDeadline("");
    setFormFallDeadline("");
    setFormAdminComment("");
    setIsAdding(true);
    setEditingId(null);
  };

  const handleOpenEdit = (u: University) => {
    setFormName(u.name);
    setFormCountryId(u.countryId);
    setFormImageUrl(u.imageUrl);
    setFormPrograms(u.programs.join(", "));
    setFormSubjects(u.subjects.join(", "));
    setFormSchFully(u.scholarship?.isFullyFunded || false);
    setFormSchTitle(u.scholarship?.title || "");
    setFormSchDesc(u.scholarship?.description || "");
    setFormSchAmount(u.scholarship?.amount || "");
    setFormSummerDeadline(u.summerDeadline || u.scholarship?.summerDeadline || "");
    setFormFallDeadline(u.fallDeadline || u.scholarship?.fallDeadline || "");
    setFormAdminComment(u.adminComment || u.scholarship?.adminComment || "");
    setEditingId(u.id);
    setIsAdding(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formCountryId) return;

    const parsedPrograms = formPrograms.split(",").map((p) => p.trim()).filter(Boolean);
    const parsedSubjects = formSubjects.split(",").map((s) => s.trim()).filter(Boolean);

    const scholarshipData = formSchTitle.trim() ? {
      isFullyFunded: formSchFully,
      title: formSchTitle,
      description: formSchDesc,
      amount: formSchAmount,
      summerDeadline: formSummerDeadline || "",
      fallDeadline: formFallDeadline || "",
      adminComment: formAdminComment || "",
    } : undefined;

    const payload = {
      name: formName,
      countryId: formCountryId,
      imageUrl: formImageUrl,
      programs: parsedPrograms,
      subjects: parsedSubjects,
      scholarship: scholarshipData,
      summerDeadline: formSummerDeadline || "",
      fallDeadline: formFallDeadline || "",
      adminComment: formAdminComment || "",
    };

    if (editingId) {
      await onUpdateUniversity(editingId, payload);
      setEditingId(null);
    } else {
      await onAddUniversity(payload);
    }
    setIsAdding(false);
  };

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this university?")) {
      await onDeleteUniversity(id);
    }
  };

  // Filtering Logic
  const filteredUniversities = universities.filter((u) => {
    const matchesCountry = selectedCountryFilter === "All" ? true : u.countryId === selectedCountryFilter;
    const matchesUniversity = selectedUniversityFilter === "All" ? true : u.id === selectedUniversityFilter;
    const matchesSearch = u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          u.subjects.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesProgram = selectedProgramFilter === "All" ? true : u.programs.includes(selectedProgramFilter);
    return matchesCountry && matchesUniversity && matchesSearch && matchesProgram;
  });

  const universitiesForSpecificFilter = universities.filter((u) => {
    return selectedCountryFilter === "All" ? true : u.countryId === selectedCountryFilter;
  });

  const getCountryName = (cId: string) => {
    return countries.find((c) => c.id === cId)?.name || "Global";
  };

  return (
    <div className="py-6 px-4 max-w-7xl mx-auto" id="universities-section">
      {/* Search and Filters row */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-gray-50 border border-gray-150 p-4 rounded-2xl mb-8" id="university-controls">
        <div className="flex-1 w-full relative">
          <label className="sr-only">Search Universities</label>
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
          <input
            type="text"
            placeholder="Search universities by name, subjects, keyword (e.g. Computer Science)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full text-sm pl-9 pr-4 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-600 placeholder:text-gray-400"
            id="uni-search-input"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          {/* Country filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-505 font-semibold">Country:</span>
            <select
              value={selectedCountryFilter}
              onChange={(e) => setSelectedCountryFilter(e.target.value)}
              className="text-xs px-3 py-2 bg-white border border-gray-200 rounded-xl focus:outline-indigo-600 font-bold"
              id="uni-country-filter"
            >
              <option value="All">All Countries</option>
              {countries.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Specific University Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-505 font-semibold">University:</span>
            <select
              value={selectedUniversityFilter}
              onChange={(e) => setSelectedUniversityFilter(e.target.value)}
              className="text-xs px-3 py-2 bg-white border border-gray-200 rounded-xl focus:outline-indigo-600 font-bold max-w-[180px] truncate"
              id="uni-specific-filter"
            >
              <option value="All">All Universities</option>
              {universitiesForSpecificFilter.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name}
                </option>
              ))}
            </select>
          </div>

          {/* Program filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-505 font-semibold">Degrees:</span>
            <select
              value={selectedProgramFilter}
              onChange={(e) => setSelectedProgramFilter(e.target.value)}
              className="text-xs px-3 py-2 bg-white border border-gray-200 rounded-xl focus:outline-indigo-600 font-bold"
              id="uni-program-filter"
            >
              <option value="All">All Levels</option>
              <option value="Bachelor">Bachelor</option>
              <option value="Master">Master</option>
              <option value="PhD">PhD</option>
            </select>
          </div>

          {/* Admin Create Uni button */}
          {isAdmin && !isAdding && (
            <button
              onClick={handleOpenAdd}
              className="indigo-action-btn inline-flex items-center gap-1 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-4 py-2 rounded-xl h-9 shadow-sm"
              id="admin-add-university-btn"
            >
              <Plus className="w-3.5 h-3.5" /> Add University
            </button>
          )}
        </div>
      </div>

      {/* Editor Block (Collapsible) */}
      {isAdding && (
        <div className="mb-8 bg-gray-50 border border-gray-200 p-6 rounded-2xl text-left" id="uni-editor-form-panel">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-base font-extrabold text-gray-900 tracking-tight">
              {editingId ? "Update Academic University File" : "Register Prestigious University Profile"}
            </h3>
            <button onClick={() => setIsAdding(false)} className="p-1 hover:bg-gray-100 rounded-full">
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">University Name *</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white"
                  placeholder="e.g. University of Edinburgh"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Country Relationship *</label>
                <select
                  required
                  value={formCountryId}
                  onChange={(e) => setFormCountryId(e.target.value)}
                  className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white font-bold"
                >
                  <option value="">Select destination country...</option>
                  {countries.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Program Degrees (comma separated) *</label>
                <input
                  type="text"
                  required
                  value={formPrograms}
                  onChange={(e) => setFormPrograms(e.target.value)}
                  className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white"
                  placeholder="e.g. Bachelor, Master"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Subjects List (comma separated) *</label>
                <input
                  type="text"
                  required
                  value={formSubjects}
                  onChange={(e) => setFormSubjects(e.target.value)}
                  className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white"
                  placeholder="e.g. Computer Science, Biotechnology"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Banner/Image URL</label>
              <input
                type="text"
                value={formImageUrl}
                onChange={(e) => setFormImageUrl(e.target.value)}
                className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white"
                placeholder="Enter custom Unsplash/web URL"
              />
            </div>

            {/* University Scholarship Section */}
            <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-4">
              <span className="text-xs font-extrabold uppercase text-indigo-750 tracking-wider flex items-center gap-1 mb-2">
                <Award className="w-4 h-4" /> Integrated Scholarship Package
              </span>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Scholarship Title</label>
                  <input
                    type="text"
                    value={formSchTitle}
                    onChange={(e) => setFormSchTitle(e.target.value)}
                    className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-650"
                    placeholder="e.g. Chancellor's International Scholarship"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Financial Award / Amount</label>
                  <input
                    type="text"
                    value={formSchAmount}
                    onChange={(e) => setFormSchAmount(e.target.value)}
                    className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-650"
                    placeholder="e.g. Full tuition cost + £10,000 allowance"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Scholarship Bio / Description</label>
                  <input
                    type="text"
                    value={formSchDesc}
                    onChange={(e) => setFormSchDesc(e.target.value)}
                    className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-650"
                    placeholder="Describe eligibility benchmarks..."
                  />
                </div>

                <div className="flex items-center gap-2 pt-6">
                  <input
                    type="checkbox"
                    id="fullyFundedTrigger"
                    checked={formSchFully}
                    onChange={(e) => setFormSchFully(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                  />
                  <label htmlFor="fullyFundedTrigger" className="text-xs font-bold text-gray-700">
                    Mark as Fully Funded Scholarship Program
                  </label>
                </div>
              </div>
            </div>

            {/* University Deadlines & Admin Comments Section */}
            <div className="bg-amber-50/50 border border-amber-100 rounded-xl p-4 space-y-3">
              <span className="text-xs font-extrabold uppercase text-amber-800 tracking-wider flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-amber-600" /> Intake Application Deadlines
              </span>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Summer Intake Deadline</label>
                  <input
                    type="date"
                    value={formSummerDeadline}
                    onChange={(e) => setFormSummerDeadline(e.target.value)}
                    className="w-full text-xs px-4 py-2 rounded-xl border border-gray-200 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Fall Intake Deadline</label>
                  <input
                    type="date"
                    value={formFallDeadline}
                    onChange={(e) => setFormFallDeadline(e.target.value)}
                    className="w-full text-xs px-4 py-2 rounded-xl border border-gray-200 bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Special Admin Note / Comment for this University</label>
                <textarea
                  rows={2}
                  value={formAdminComment}
                  onChange={(e) => setFormAdminComment(e.target.value)}
                  placeholder="e.g. Seats fill up fast. Apply at least 15 days before the declared countdown."
                  className="w-full text-xs px-4 py-2.5 rounded-xl border border-gray-200 bg-white"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 pb-1">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 text-xs font-semibold bg-white border border-gray-250 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-xl shadow-sm hover:bg-indigo-700"
              >
                {editingId ? "Save University" : "Publish University"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* University Cards Layout */}
      {filteredUniversities.length === 0 ? (
        <div className="bg-white border rounded-2xl py-12 px-4 text-center max-w-lg mx-auto" id="no-university-fallback">
          <BookOpen className="w-10 h-10 text-gray-300 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-gray-900">No Universities Found</h3>
          <p className="text-sm text-gray-500 mt-1">
            No active profiles match your filter options. Try clear your search phrase or choose 'All Levels'.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="university-cards-grid">
          {filteredUniversities.map((uni) => (
            <div
              key={uni.id}
              className="bg-white border border-gray-100 rounded-2xl overflow-hidden hover:shadow-xl transition-all flex flex-col h-full text-left"
              id={`university-card-${uni.id}`}
            >
              <div className="h-44 relative overflow-hidden bg-gray-50">
                <img
                  src={uni.imageUrl || "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=800"}
                  alt={uni.name}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-102"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=800";
                  }}
                />

                {/* Country Badge */}
                <div className="absolute top-3 left-3">
                  <span className="text-[10px] tracking-wide font-bold uppercase bg-white/90 backdrop-blur-md text-gray-900 px-3 py-1 rounded-full shadow-sm">
                    {getCountryName(uni.countryId)}
                  </span>
                </div>

                {/* Direct fully funded seal banner */}
                {uni.scholarship?.isFullyFunded && (
                  <div className="absolute top-3 right-3">
                    <span className="inline-flex items-center gap-1 text-[10px] bg-amber-500 text-white font-extrabold px-2.5 py-1 rounded-full shadow-md animate-pulse">
                      <Sparkles className="w-3 h-3" /> Fully Funded
                    </span>
                  </div>
                )}
              </div>

              {/* Body */}
              <div className="p-5 flex-1 flex flex-col">
                <div className="flex-1">
                  <h3 className="text-xl font-extrabold text-gray-900 tracking-tight line-clamp-1">{uni.name}</h3>
                  
                  {/* Degrees */}
                  <div className="flex flex-wrap gap-1.5 mt-2.5">
                    {uni.programs.map((prog, idx) => (
                      <span key={idx} className="text-[10px] px-2 py-0.5 bg-indigo-50 border border-indigo-100 text-indigo-755 font-bold rounded">
                        {prog}
                      </span>
                    ))}
                  </div>

                  {/* Subjects list */}
                  <div className="mt-4" id={`subjects-list-${uni.id}`}>
                    <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider flex items-center gap-1">
                      <Target className="w-3 h-3" /> Key Specialized Fields
                    </span>
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {uni.subjects.map((sub, idx) => (
                        <span key={idx} className="text-[10px] px-2 py-0.5 bg-gray-100 text-gray-655 font-medium rounded-sm">
                          {sub}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Scholarship micro highlight */}
                  {uni.scholarship && uni.scholarship.title && (
                    <div className="mt-4 p-3 bg-amber-50/60 rounded-xl border border-amber-100/55 flex gap-2">
                      <Award className="w-4 h-4 text-amber-650 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-[11px] font-bold text-amber-900 line-clamp-1">{uni.scholarship.title}</div>
                        <div className="text-[10px] font-semibold text-amber-700/80 mt-0.5">{uni.scholarship.amount}</div>
                      </div>
                    </div>
                  )}
                  {/* University Deadlines Countdown & Admin Comment Display with Scholarship fallback */}
                  {(() => {
                    const sDeadline = uni.summerDeadline || uni.scholarship?.summerDeadline;
                    const fDeadline = uni.fallDeadline || uni.scholarship?.fallDeadline;
                    const sComment = uni.adminComment || uni.scholarship?.adminComment;

                    if (!sDeadline && !fDeadline && !sComment) return null;

                    return (
                      <div className="mt-4 p-3 bg-slate-50 border border-slate-100 rounded-xl space-y-2">
                        <div className="text-[10px] uppercase font-bold text-gray-500 tracking-wider flex items-center gap-1 border-b border-gray-150 pb-1 mr-1">
                          <Clock className="w-3.5 h-3.5 text-indigo-500" /> Intake Deadlines & Days Left
                        </div>
                        
                        <div className="space-y-1.5 text-xs">
                          {sDeadline && (() => {
                            const countdown = getCountdown(sDeadline);
                            return (
                              <div className="flex justify-between items-center bg-white p-1.5 rounded-lg border border-gray-150 shadow-2xs">
                                <div>
                                  <span className="font-extrabold text-gray-700 text-[11px]">Summer Intake</span>
                                  <span className="text-[9px] text-gray-450 block leading-tight">{formatDate(sDeadline)}</span>
                                </div>
                                {countdown && (
                                  <span className={`px-2 py-0.5 rounded-full font-bold text-[9px] uppercase ${
                                    countdown.days === 0 
                                      ? "bg-red-50 text-red-600 border border-red-100" 
                                      : countdown.days <= 10 
                                        ? "bg-amber-50 text-amber-750 border border-amber-150 animate-pulse" 
                                        : "bg-emerald-50 text-emerald-700 border border-emerald-100"
                                  }`}>
                                    {countdown.text}
                                  </span>
                                )}
                              </div>
                            );
                          })()}

                          {fDeadline && (() => {
                            const countdown = getCountdown(fDeadline);
                            return (
                              <div className="flex justify-between items-center bg-white p-1.5 rounded-lg border border-gray-150 shadow-2xs">
                                <div>
                                  <span className="font-extrabold text-gray-700 text-[11px]">Fall Intake</span>
                                  <span className="text-[9px] text-gray-455 block leading-tight">{formatDate(fDeadline)}</span>
                                </div>
                                {countdown && (
                                  <span className={`px-2 py-0.5 rounded-full font-bold text-[9px] uppercase ${
                                    countdown.days === 0 
                                      ? "bg-red-50 text-red-600 border border-red-100" 
                                      : countdown.days <= 10 
                                        ? "bg-amber-50 text-amber-755 border border-amber-150 animate-pulse" 
                                        : "bg-emerald-50 text-emerald-700 border border-emerald-100"
                                  }`}>
                                    {countdown.text}
                                  </span>
                                )}
                              </div>
                            );
                          })()}
                        </div>

                        {sComment && (
                          <div className="bg-amber-50/40 border border-amber-100/50 p-2 rounded-lg text-[10px] text-amber-900 leading-relaxed italic flex gap-1 items-start">
                            <MessageSquare className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                            <span>{sComment}</span>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>

                {/* Bottom Action bar */}
                <div className="mt-5 pt-4 border-t border-gray-50 flex items-center justify-between">
                  {isAdmin ? (
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleOpenEdit(uni)}
                        className="inline-flex items-center gap-1 p-2 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold"
                      >
                        <Edit3 className="w-3.5 h-3.5" /> Edit
                      </button>
                      <button
                        onClick={() => handleDelete(uni.id)}
                        className="indigo-action-btn inline-flex items-center gap-1 p-2 h-8 rounded-lg bg-red-50 hover:bg-red-100 text-red-650 text-xs font-semibold"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Delete
                      </button>
                    </div>
                  ) : (
                    <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">Admissions Open</span>
                  )}

                  <button
                    onClick={() => onApply(uni)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm inline-flex items-center gap-1.5 transition-all"
                  >
                    Apply Now <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
