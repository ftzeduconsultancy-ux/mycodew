import React, { useState } from "react";
import { University, User, DocumentUpload } from "../types";
import { X, FileText, Upload, Plus, Trash2, CheckCircle, ArrowRight, ShieldAlert } from "lucide-react";

interface ApplicationModalProps {
  university: University;
  user: User | null;
  onClose: () => void;
  onSubmit: (payload: {
    studentId: string;
    universityId: string;
    program: string;
    passportNumber: string;
    documents: DocumentUpload[];
    comment: string;
  }) => Promise<void>;
  storageDestination: string;
}

export default function ApplicationModal({
  university,
  user,
  onClose,
  onSubmit,
  storageDestination
}: ApplicationModalProps) {
  const [program, setProgram] = useState(university.programs[0] || "Bachelor");
  const [passportNumber, setPassportNumber] = useState("");
  const [comment, setComment] = useState("");
  const [signature, setSignature] = useState("");
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [documents, setDocuments] = useState<DocumentUpload[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form student user details
  const studentName = user ? user.name : "";
  const studentEmail = user ? user.email : "";

  // Uploading handler using API base64 parser
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const reader = new FileReader();
    
    reader.onloadend = async () => {
      const base64Data = reader.result as string;
      try {
        const res = await fetch("/api/upload", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            fileName: file.name,
            base64Data: base64Data,
          }),
        });
        
        if (res.ok) {
          const uploaded = await res.json();
          const docItem: DocumentUpload = {
            name: uploaded.name,
            url: uploaded.url,
            size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
            uploadedAt: new Date().toISOString(),
          };
          setDocuments((prev) => [...prev, docItem]);
        } else {
          alert("Failed to upload document file. Please make sure the size is small.");
        }
      } catch (err) {
        console.error("Upload error", err);
        alert("Upload error.");
      } finally {
        setIsUploading(false);
      }
    };

    reader.readAsDataURL(file);
  };

  const handleRemoveDoc = (index: number) => {
    setDocuments((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert("Please sign in or register before submitting an application.");
      return;
    }
    if (user.status !== "approved") {
      alert("Your account is pending administrator approval. Please wait for the admin's check.");
      return;
    }
    if (!passportNumber.trim()) {
      alert("Passport number is required.");
      return;
    }
    if (!acceptTerms) {
      alert("Please accept the Terms & Conditions declaration stating you willingly apply.");
      return;
    }
    if (!signature.trim()) {
      alert("Please provide your formal digital signature.");
      return;
    }

    setIsSubmitting(true);
    try {
      const formattedComment = `[Digital Signature: ${signature.trim()}] [Willingness Declared: Yes] [Multiple Offers Choice Right Guaranteed: Student reserves absolute right to choose preferred university and scholarship package upon receiving multiple offers]${comment.trim() ? " \n\nAdditional Comments: " + comment.trim() : ""}`;
      await onSubmit({
        studentId: user.id,
        universityId: university.id,
        program,
        passportNumber,
        documents,
        comment: formattedComment,
      });
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" id="application-modal">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-gray-900/60 transition-opacity backdrop-blur-xs" onClick={onClose} />

      <div className="flex min-h-full items-center justify-center p-4 text-center">
        <div className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all w-full max-w-2xl border border-gray-150 flex flex-col my-8">
          
          {/* Header */}
          <div className="bg-indigo-900 px-6 py-4 text-white flex justify-between items-center">
            <div>
              <span className="text-[10px] uppercase tracking-wider text-indigo-200 font-extrabold">Admissions Registry Applet</span>
              <h3 className="text-xl font-bold tracking-tight text-white mt-0.5">Apply to {university.name}</h3>
            </div>
            <button onClick={onClose} className="text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10">
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmitForm} className="p-6 space-y-4 flex-1">
            {/* Account check banner */}
            {!user ? (
              <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-amber-900/90 text-xs text-left">
                <ShieldAlert className="w-5 h-5 text-amber-600 inline-block mr-2 align-middle -mt-0.5" />
                <span>You are currently a guest student. To finalize enrollment, you must first register and gain approval from our lead administrator in the Sign-In panel.</span>
              </div>
            ) : user.status === "pending" ? (
              <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-amber-900/90 text-xs text-left">
                <ShieldAlert className="w-5 h-5 text-amber-600 inline-block mr-2 align-middle" />
                <span>Alex, your portal user registration is currently pending lead credentials verification. Please coordinate with an admin before continuing.</span>
              </div>
            ) : null}

            {/* General student detail preview */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="text-left bg-gray-50 p-3 rounded-xl border border-gray-100">
                <span className="text-[10px] text-gray-400 font-bold uppercase">Applicant Name</span>
                <p className="text-sm font-extrabold text-gray-950 mt-0.5">{studentName || "Guest User"}</p>
              </div>
              <div className="text-left bg-gray-50 p-3 rounded-xl border border-gray-100">
                <span className="text-[10px] text-gray-400 font-bold uppercase">Applicant Email</span>
                <p className="text-sm font-semibold text-gray-700 mt-0.5 truncate">{studentEmail || "Not logged in"}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Program Selector */}
              <div className="text-left">
                <label className="block text-xs font-semibold text-gray-750 uppercase tracking-wide mb-1">Target Academic Degree *</label>
                <select
                  value={program}
                  onChange={(e) => setProgram(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-200 bg-white font-bold"
                >
                  {university.programs.map((p, idx) => (
                    <option key={idx} value={p}>
                      {p} Degree
                    </option>
                  ))}
                </select>
              </div>

              {/* Passport details */}
              <div className="text-left">
                <label className="block text-xs font-semibold text-gray-750 uppercase tracking-wide mb-1">Passport / ID Number *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. N-90812398"
                  value={passportNumber}
                  onChange={(e) => setPassportNumber(e.target.value)}
                  disabled={!user || user.status === "pending"}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-650"
                />
              </div>
            </div>

             {/* Document upload system (Optional) */}
            <div className="bg-indigo-50/40 p-4 border border-indigo-100 rounded-xl space-y-3 text-left">
              <div className="flex justify-between items-center sm:flex-row flex-col gap-2">
                <div>
                  <span className="text-xs font-bold text-indigo-950 block">Optional Support Credentials</span>
                  <p className="text-[10px] text-gray-500 mt-0.5">Academic transcripts, test scores, or ID copies (No portfolio dossier is required).</p>
                </div>
                {/* Secondary destination storage notifier */}
                <div className="text-right">
                  <span className="inline-block text-[10px] bg-indigo-100 text-indigo-800 font-bold px-2 py-0.5 rounded border border-indigo-200 uppercase">
                    Storage: Google Drive Linked
                  </span>
                </div>
              </div>

              {/* Upload Dropzone */}
              <label className="border-2 border-dashed border-indigo-200 rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer hover:bg-white hover:border-indigo-400 transition-all text-center">
                <Upload className="w-8 h-8 text-indigo-400 mb-1" />
                <span className="text-xs font-bold text-indigo-900">Drag & drop optional files here or click to browse</span>
                <span className="text-[10px] text-gray-400 mt-0.5">Maximum attachment limit: 10 MB per document</span>
                <input
                  type="file"
                  accept=".pdf, image/*"
                  onChange={handleFileUpload}
                  disabled={isUploading || !user || user.status === "pending"}
                  className="hidden"
                />
              </label>

              {isUploading && (
                <div className="text-xs text-indigo-655 font-bold animate-pulse text-center">
                  Compressing and digitizing attachments...
                </div>
              )}

              {/* List of files added */}
              {documents.length > 0 && (
                <div className="space-y-1.5 pt-2" id="uploaded-files-list">
                  {documents.map((doc, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-white px-3 py-2 rounded-lg border border-gray-150 text-xs">
                      <span className="flex items-center gap-1.5 text-gray-800 font-semibold truncate max-w-[320px]">
                        <FileText className="w-4 h-4 text-indigo-500 shrink-0" /> {doc.name}
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-gray-400">{doc.size}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveDoc(idx)}
                          className="p-1 text-red-500 hover:bg-red-50 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Terms and Conditions declaration and digital signature */}
            <div className="bg-gray-50 p-4 border border-gray-200 rounded-xl space-y-3.5 text-left">
              <span className="text-xs font-bold text-gray-950 block uppercase tracking-wider">Candidate Declarations & Integrity checks</span>
              
              <div className="flex items-start gap-2.5">
                <input
                  type="checkbox"
                  id="accept-terms-checkbox"
                  checked={acceptTerms}
                  onChange={(e) => setAcceptTerms(e.target.checked)}
                  disabled={!user || user.status === "pending"}
                  className="mt-1 h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-550 cursor-pointer"
                />
                <label htmlFor="accept-terms-checkbox" className="text-xs font-semibold text-gray-700 leading-relaxed cursor-pointer select-none">
                  I certify that <strong className="text-gray-900">I willingly apply</strong> for enrollment. I have stated all my demands/requirements in the comment option below; if those terms are acquired and satisfied, I agree that <strong className="text-gray-900">I must accept the university</strong>.
                </label>
              </div>

              <div className="border-t border-gray-150 pt-3 space-y-2">
                <span className="text-[11px] font-extrabold uppercase text-indigo-700 tracking-wider flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-indigo-600" />
                  Your Right to Choice & Scholarship
                </span>
                <p className="text-xs font-medium text-gray-750 leading-relaxed pl-5">
                  By institutional regulations, <strong className="text-gray-950">if you receive multiple placement offer letters</strong>, you possess the <strong className="text-indigo-650">absolute student right to choose your preferred university and scholarship offer</strong> as per your wish, freely and without any external penalty.
                </p>
              </div>

              <div className="border-t border-gray-200/60 pt-3">
                <label className="block text-xs font-bold text-gray-750 uppercase mb-1">Applicant Formal Digital Signature *</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="Type your full legal name to sign"
                    value={signature}
                    onChange={(e) => setSignature(e.target.value)}
                    disabled={!user || user.status === "pending"}
                    className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-650 font-medium italic text-indigo-950 tracking-wide"
                  />
                  {signature.trim() && (
                    <span className="absolute right-3.5 top-2 text-[9px] font-black uppercase text-emerald-750 bg-emerald-55/80 px-2 py-1 rounded-md border border-emerald-200">
                      Digitally Verified
                    </span>
                  )}
                </div>
                <span className="text-[10px] text-gray-400 mt-1 block">A digital signature matches database records indicating formal verification.</span>
              </div>
            </div>

            {/* Notes Section */}
            <div className="text-left">
              <label className="block text-xs font-semibold text-gray-750 uppercase tracking-wide mb-1">Optional Comments</label>
              <textarea
                placeholder="Specify scholarship preferences, visa timeline constraints, or queries..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                disabled={!user || user.status === "pending"}
                rows={2}
                className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-655"
              />
            </div>

            {/* Bottom action block */}
            <div className="pt-4 border-t border-gray-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 border border-transparent text-gray-800 font-semibold text-xs rounded-xl"
              >
                Cancel Review
              </button>
              <button
                type="submit"
                disabled={isSubmitting || isUploading || !user || user.status === "pending" || !acceptTerms || !signature.trim()}
                className={`px-5 py-2 rounded-xl text-xs font-bold text-white shadow-md inline-flex items-center gap-1 ${
                  isSubmitting || isUploading || !user || user.status === "pending" || !acceptTerms || !signature.trim()
                    ? "bg-indigo-300 cursor-not-allowed text-white/50"
                    : "bg-indigo-600 hover:bg-indigo-700"
                }`}
                id="submit-app-btn"
              >
                {isSubmitting ? "Creating Application File..." : "Submit Formal Application"} <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
