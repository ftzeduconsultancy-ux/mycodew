import React, { useState } from "react";
import { University, Country, User, GlobalScholarship } from "../types";
import { Award, GraduationCap, Building2, Globe, Sparkles, Plus, Pencil, Trash2, X, Link, Image as ImageIcon, Coins, ArrowUpRight, Calendar, Clock, MessageSquare } from "lucide-react";
import { getCountdown, formatDate } from "./UniversitySection";

interface ScholarshipSectionProps {
  universities: University[];
  countries: Country[];
  scholarships?: GlobalScholarship[];
  onApply: (uni: University) => void;
  user?: User | null;
  onUpdateUniversity?: (id: string, updated: Partial<University>) => Promise<void>;
  onAddUniversity?: (newUni: Omit<University, "id">) => Promise<void>;
  onDeleteUniversity?: (id: string) => Promise<void>;
  onAddScholarship?: (newSch: Omit<GlobalScholarship, "id">) => Promise<void>;
  onUpdateScholarship?: (id: string, updated: Partial<GlobalScholarship>) => Promise<void>;
  onDeleteScholarship?: (id: string) => Promise<void>;
}

export default function ScholarshipSection({ 
  universities, 
  countries, 
  scholarships = [],
  onApply,
  user,
  onAddScholarship,
  onUpdateScholarship,
  onDeleteScholarship,
}: ScholarshipSectionProps) {
  const [filterType, setFilterType] = useState<"all" | "fully" | "partial">("all");

  const isAdmin = user?.role === "admin";

  // Form State for dynamic admin scholarship editing
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [isFully, setIsFully] = useState(false);
  const [countryId, setCountryId] = useState("");
  const [universeId, setUniverseId] = useState(""); // EMPTY means university is NOT mandatory / country wide!
  const [customUnivName, setCustomUnivName] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [summerDeadline, setSummerDeadline] = useState("");
  const [fallDeadline, setFallDeadline] = useState("");
  const [adminComment, setAdminComment] = useState("");

  const getCountryName = (cId: string) => {
    return countries.find((c) => c.id === cId)?.name || "Global";
  };

  const getCountryImage = (cId: string) => {
    return countries.find((c) => c.id === cId)?.imageUrl || "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=800";
  };

  const uniScholarships: GlobalScholarship[] = universities
    .filter((u) => u.scholarship && u.scholarship.title)
    .map((u) => ({
      id: `uni-sch-${u.id}`,
      title: u.scholarship!.title,
      description: u.scholarship!.description || "",
      amount: u.scholarship!.amount || "",
      isFullyFunded: !!u.scholarship!.isFullyFunded,
      countryId: u.countryId,
      universityId: u.id,
      universityName: u.name,
      imageUrl: u.imageUrl,
      summerDeadline: u.scholarship!.summerDeadline || u.summerDeadline || "",
      fallDeadline: u.scholarship!.fallDeadline || u.fallDeadline || "",
      adminComment: u.scholarship!.adminComment || u.adminComment || "",
    }));

  const combinedScholarships = [...scholarships, ...uniScholarships];

  const activeScholarships = combinedScholarships.filter((item) => {
    if (filterType === "fully") return item.isFullyFunded;
    if (filterType === "partial") return !item.isFullyFunded;
    return true;
  });

  const handleOpenAdd = () => {
    setTitle("");
    setDescription("");
    setAmount("");
    setIsFully(false);
    setCountryId(countries[0]?.id || "");
    setUniverseId(""); // University NOT mandatory by default
    setCustomUnivName("");
    setImageUrl("");
    setSummerDeadline("");
    setFallDeadline("");
    setAdminComment("");
    setEditingId(null);
    setIsFormOpen(true);
  };

  const handleOpenEdit = (sch: GlobalScholarship) => {
    setTitle(sch.title);
    setDescription(sch.description);
    setAmount(sch.amount);
    setIsFully(sch.isFullyFunded);
    setCountryId(sch.countryId);
    setUniverseId(sch.universityId || "");
    setCustomUnivName(sch.universityName || "");
    setImageUrl(sch.imageUrl || "");
    setSummerDeadline(sch.summerDeadline || "");
    setFallDeadline(sch.fallDeadline || "");
    setAdminComment(sch.adminComment || "");
    setEditingId(sch.id);
    setIsFormOpen(true);
  };

  const handleRemove = async (sch: GlobalScholarship) => {
    if (!onDeleteScholarship) return;
    if (confirm(`Are you sure you want to delete "${sch.title}"?`)) {
      try {
        await onDeleteScholarship(sch.id);
        alert("Scholarship program deleted successfully from the catalog.");
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!countryId) {
      alert("Please select a target country.");
      return;
    }

    if (!title.trim() || !amount.trim()) {
      alert("Please fill out all mandatory fields.");
      return;
    }

    // Resolve an automatic placeholder image if none passed
    let finalImageUrl = imageUrl.trim();
    if (!finalImageUrl) {
      if (universeId) {
        const u = universities.find((u) => u.id === universeId);
        if (u) finalImageUrl = u.imageUrl;
      }
      if (!finalImageUrl) {
        finalImageUrl = getCountryImage(countryId);
      }
    }

    const matchedUni = universities.find((u) => u.id === universeId);
    const payload = {
      title,
      description,
      amount,
      isFullyFunded: isFully,
      countryId,
      universityId: universeId || undefined,
      universityName: universeId ? matchedUni?.name : (customUnivName.trim() || undefined),
      imageUrl: finalImageUrl,
      summerDeadline: summerDeadline || "",
      fallDeadline: fallDeadline || "",
      adminComment: adminComment || "",
    };

    try {
      if (editingId) {
        if (onUpdateScholarship) {
          await onUpdateScholarship(editingId, payload);
          alert("Scholarship updated successfully!");
        }
      } else {
        if (onAddScholarship) {
          await onAddScholarship(payload);
          alert("New country/university scholarship registered successfully!");
        }
      }
      setIsFormOpen(false);
    } catch (err) {
      console.error(err);
    }
  };

  // Safe launcher apply flow
  const handleApplyClick = (sch: GlobalScholarship) => {
    if (sch.universityId) {
      const u = universities.find((uni) => uni.id === sch.universityId);
      if (u) {
        onApply(u);
        return;
      }
    }
    
    // Create virtual university dynamically so students can apply for the country-wide / government scholarship directly!
    const virtualUni: University = {
      id: "u-sch-" + sch.id,
      name: sch.universityName || sch.title,
      countryId: sch.countryId,
      imageUrl: sch.imageUrl || getCountryImage(sch.countryId),
      programs: ["Scholarship Program Only (Full Funding)"],
      subjects: ["All Supported Disciplines & Priorities"],
    };
    onApply(virtualUni);
  };

  return (
    <div className="py-8 px-4 max-w-7xl mx-auto" id="scholarships-section">
      {/* Editorial Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-xs font-bold uppercase tracking-widest text-amber-600 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
          Global Financial Support
        </span>
        <h1 className="text-3xl font-extrabold text-gray-950 mt-3 tracking-tight">
          Elite Scholarships & Fellowships
        </h1>
        <p className="text-sm text-gray-500 mt-2 leading-relaxed">
          Access premium fully-funded university grants & national government scholarships (such as Chinese or Russian state models) to ease your learning journey.
        </p>

        {/* Admin Premium Scholarship Add trigger */}
        {isAdmin && (
          <div className="mt-4 flex justify-center">
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 text-xs font-black uppercase text-white bg-indigo-650 hover:bg-indigo-750 px-4 py-2.5 rounded-xl transition-all shadow-sm cursor-pointer"
              id="admin-add-scholarship-front"
            >
              <Plus className="w-4 h-4" /> Add Scholarship / Fellowship
            </button>
          </div>
        )}
      </div>

      {/* Dynamic admin modal or inline drawer */}
      {isFormOpen && isAdmin && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in animate-duration-150" id="scholarship-modal-admin">
          <div className="bg-white border border-gray-150 p-6 rounded-3xl w-full max-w-lg shadow-xl relative text-left max-h-[90vh] overflow-y-auto">
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-900 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-base font-extrabold text-indigo-950 mb-4 flex items-center gap-1.5">
              <Award className="w-5 h-5 text-indigo-600" />
              {editingId ? "✏️ Edit Scholarship Opportunity" : "🏆 Add New Scholarship / Fellowship"}
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              
              <div>
                <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Scholarship Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Chinese Government Scholarship (CSC)"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-200 bg-white"
                />
              </div>

              {/* Target Country Selector - Mandatory */}
              <div>
                <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Target Country (Mandatory) *</label>
                <select
                  required
                  value={countryId}
                  onChange={(e) => setCountryId(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-200 bg-white font-bold text-gray-900"
                >
                  <option value="">Select country...</option>
                  {countries.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Partner University - Optional */}
                <div>
                  <label className="block text-[10px] uppercase font-bold text-gray-400 mb-1 flex items-center gap-1">
                    <Building2 className="w-3.5 h-3.5 text-gray-400" /> Partner College (Optional)
                  </label>
                  <select
                    value={universeId}
                    onChange={(e) => {
                      setUniverseId(e.target.value);
                      if (e.target.value) {
                        setCustomUnivName(""); // Clear custom name if partner is chosen
                      }
                    }}
                    className="w-full text-xs px-3 py-2.5 rounded-xl border border-gray-200 bg-white"
                  >
                    <option value="">-- No specified Partner / Country-Wide --</option>
                    {universities
                      .filter((u) => !countryId || u.countryId === countryId)
                      .map((u) => (
                        <option key={u.id} value={u.id}>
                          {u.name}
                        </option>
                      ))}
                  </select>
                </div>

                {/* Free Text Custom University Name - Optional */}
                <div>
                  <label className="block text-[10px] uppercase font-bold text-gray-400 mb-1">
                    Custom Institution Name (Optional)
                  </label>
                  <input
                    type="text"
                    disabled={!!universeId}
                    placeholder={universeId ? "Locked (Partner Selected)" : "e.g. All State Universities"}
                    value={customUnivName}
                    onChange={(e) => setCustomUnivName(e.target.value)}
                    className="w-full text-xs px-3 py-2.5 rounded-xl border border-gray-200 bg-white disabled:bg-gray-50 disabled:text-gray-400"
                  />
                  <p className="text-[9px] text-gray-400 mt-0.5 font-medium">Use when university is not partner.</p>
                </div>
              </div>

              {/* Cover Image URL input */}
              <div>
                <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1 flex items-center gap-1">
                  <ImageIcon className="w-3.5 h-3.5 text-indigo-500" /> Beautiful Image / Photo Option (Optional)
                </label>
                <div className="space-y-1.5 bg-gray-50/50 p-2.5 rounded-xl border border-gray-150">
                  <input
                    type="text"
                    placeholder="Paste custom secure photo URL..."
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    className="w-full text-xs px-3 py-1.5 rounded-xl border border-gray-200 bg-white focus:ring-1 focus:ring-indigo-500 font-medium"
                  />
                  <label className="flex items-center gap-1.5 cursor-pointer text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-100 hover:bg-indigo-100 px-2 py-1.5 rounded-lg justify-center transition-colors font-bold">
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>Upload local image file</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            if (typeof reader.result === "string") {
                              setImageUrl(reader.result);
                            }
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                </div>
                <p className="text-[9px] text-gray-400 mt-0.5 font-medium">Provide a beautiful image URL or upload a local photo for this university/scholarship card.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Funding Award/Stipend Value *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 100% Tuition Waiver + Free Dorm"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full text-xs px-3 py-2.5 rounded-xl border border-gray-200 bg-white"
                  />
                </div>
                
                <div className="flex items-center gap-2 pt-5">
                  <input
                    type="checkbox"
                    id="frontSchFully"
                    checked={isFully}
                    onChange={(e) => setIsFully(e.target.checked)}
                    className="rounded border-gray-300 text-indigo-600 h-4 w-4"
                  />
                  <label htmlFor="frontSchFully" className="text-xs font-bold text-gray-750 cursor-pointer">Mark as 100% Fully Funded</label>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Detailed Description of Criterion / Coverage</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Detail grant eligibility, requirements, monthly stipends, and total tuition coverage."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-200 bg-white focus:outline-indigo-650"
                />
              </div>

              {/* Scholarship Deadlines & Admin Comments Section */}
              <div className="bg-amber-50/50 border border-amber-100 rounded-xl p-4 space-y-3">
                <span className="text-[10px] font-extrabold uppercase text-amber-800 tracking-wider flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-amber-600" /> Scholarship Intake Deadlines
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Summer Intake Deadline</label>
                    <input
                      type="date"
                      value={summerDeadline}
                      onChange={(e) => setSummerDeadline(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Fall Intake Deadline</label>
                    <input
                      type="date"
                      value={fallDeadline}
                      onChange={(e) => setFallDeadline(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-xl border border-gray-200 bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold text-gray-600 mb-1">Special Admin Note / Comment for this Scholarship</label>
                  <textarea
                    rows={2}
                    value={adminComment}
                    onChange={(e) => setAdminComment(e.target.value)}
                    placeholder="e.g. Open to international students directly via embassy review channels."
                    className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-gray-200 bg-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-gray-650 bg-white border border-gray-200 hover:bg-gray-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-indigo-650 hover:bg-indigo-700 rounded-xl shadow-xs cursor-pointer"
                >
                  {editingId ? "Save Changes" : "Create Scholarship Option"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex justify-center gap-2 mb-8" id="scholarship-filter-panel">
        <button
          onClick={() => setFilterType("all")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
            filterType === "all"
              ? "bg-indigo-600 text-white border-indigo-700 shadow-sm"
              : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"
          }`}
        >
          All Opportunities ({scholarships.length})
        </button>
        <button
          onClick={() => setFilterType("fully")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border inline-flex items-center gap-1 cursor-pointer ${
            filterType === "fully"
              ? "bg-amber-550 text-white border-amber-600 shadow-sm"
              : "bg-white text-amber-500 border-amber-200 hover:bg-amber-50"
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" /> Fully Funded ({scholarships.filter((s) => s.isFullyFunded).length})
        </button>
        <button
          onClick={() => setFilterType("partial")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
            filterType === "partial"
              ? "bg-indigo-50 text-indigo-700 border-indigo-200 shadow-sm"
              : "bg-white text-gray-650 border-gray-200 hover:bg-gray-50"
          }`}
        >
          Partial Scholarships ({scholarships.filter((s) => !s.isFullyFunded).length})
        </button>
      </div>

      {/* Grid Layout of Scholarships */}
      {activeScholarships.length === 0 ? (
        <div className="bg-white border rounded-2xl py-12 px-4 text-center max-w-lg mx-auto shadow-xs">
          <GraduationCap className="w-10 h-10 text-gray-300 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-gray-900">No Scholarships Found</h3>
          <p className="text-sm text-gray-500 mt-1">
            No active scholarships match the selected tier filter.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="scholarships-grid">
          {activeScholarships.map((sch) => (
            <div
              key={sch.id}
              className={`bg-white border select-none rounded-2xl overflow-hidden flex flex-col h-full text-left relative transition-all hover:shadow-md ${
                sch.isFullyFunded ? "border-amber-300 ring-1 ring-amber-200/50 shadow-xs" : "border-gray-200"
              }`}
            >
              {sch.isFullyFunded && (
                <div className="absolute top-4 right-4 z-10 animate-pulse">
                  <span className="bg-amber-500 text-white font-extrabold text-[9px] uppercase px-3 py-1 rounded-full shadow-sm flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Fully Funded
                  </span>
                </div>
              )}

              {/* Card Header Illustration / Photo URL */}
              <div className="h-44 bg-slate-950 relative">
                <img
                  src={sch.imageUrl || getCountryImage(sch.countryId)}
                  alt={sch.title}
                  className="w-full h-full object-cover opacity-60"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 to-transparent" />
                
                {/* Location indicator flag */}
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <span className="text-[10px] text-amber-300 font-bold uppercase tracking-widest flex items-center gap-1">
                    <Globe className="w-3 h-3" /> {getCountryName(sch.countryId)}
                  </span>
                  <h3 className="text-base font-extrabold text-white mt-0.5 line-clamp-1">{sch.universityName || "National Government Program"}</h3>
                </div>
              </div>

              {/* Card Meta details */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-750 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100">
                    <Award className="w-4 h-4 text-indigo-500" /> {sch.title}
                  </div>

                  <p className="text-xs text-gray-600 leading-relaxed font-normal min-h-[50px] line-clamp-3">
                    {sch.description || "Fully-funded grant offered on outstanding scholastic credentials to relieve overall travel and campus costs."}
                  </p>

                  <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-100 mt-2 text-xs">
                    <div>
                      <span className="text-[9px] text-gray-400 font-bold uppercase block tracking-wider">Reward Value</span>
                      <span className="font-extrabold text-indigo-900 line-clamp-1">{sch.amount}</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-gray-400 font-bold uppercase block tracking-wider">University Target</span>
                      <span className="font-extrabold text-gray-700 truncate block">
                        {sch.universityId ? "Partner University" : "Broad National Scheme"}
                      </span>
                    </div>
                  </div>

                  {/* Scholarship Deadlines Countdown & Admin Comment Display */}
                  {(sch.summerDeadline || sch.fallDeadline || sch.adminComment) && (
                    <div className="mt-4 p-3 bg-slate-50 border border-slate-100 rounded-xl space-y-2">
                       <div className="text-[10px] uppercase font-bold text-gray-500 tracking-wider flex items-center gap-1 border-b border-gray-150 pb-1 mr-1">
                        <Clock className="w-3.5 h-3.5 text-indigo-505" /> Intake Deadlines & Days Left
                      </div>
                      
                      <div className="space-y-1.5 text-xs">
                        {sch.summerDeadline && (() => {
                          const countdown = getCountdown(sch.summerDeadline);
                          return (
                            <div className="flex justify-between items-center bg-white p-1.5 rounded-lg border border-gray-150 shadow-2xs">
                              <div>
                                <span className="font-extrabold text-gray-700 text-[11px]">Summer Intake</span>
                                <span className="text-[9px] text-gray-455 block leading-tight">{formatDate(sch.summerDeadline)}</span>
                              </div>
                              {countdown && (
                                <span className={`px-2 py-0.5 rounded-full font-bold text-[9px] uppercase ${
                                  countdown.days === 0 
                                    ? "bg-red-50 text-red-650 border border-red-100" 
                                    : countdown.days <= 10 
                                      ? "bg-amber-50 text-amber-705 border border-amber-150 animate-pulse" 
                                      : "bg-emerald-50 text-emerald-705 border border-emerald-100"
                                }`}>
                                  {countdown.text}
                                </span>
                              )}
                            </div>
                          );
                        })()}

                        {sch.fallDeadline && (() => {
                          const countdown = getCountdown(sch.fallDeadline);
                          return (
                            <div className="flex justify-between items-center bg-white p-1.5 rounded-lg border border-gray-150 shadow-2xs">
                              <div>
                                <span className="font-extrabold text-gray-700 text-[11px]">Fall Intake</span>
                                <span className="text-[9px] text-gray-455 block leading-tight">{formatDate(sch.fallDeadline)}</span>
                              </div>
                              {countdown && (
                                <span className={`px-2 py-0.5 rounded-full font-bold text-[9px] uppercase ${
                                  countdown.days === 0 
                                    ? "bg-red-50 text-red-650 border border-red-100" 
                                    : countdown.days <= 10 
                                      ? "bg-amber-50 text-amber-705 border border-amber-150 animate-pulse" 
                                      : "bg-emerald-50 text-emerald-705 border border-emerald-100"
                                }`}>
                                  {countdown.text}
                                </span>
                              )}
                            </div>
                          );
                        })()}
                      </div>

                      {sch.adminComment && (
                        <div className="bg-amber-50/40 border border-amber-100/50 p-2 rounded-lg text-[10px] text-amber-900 leading-relaxed italic flex gap-1 items-start">
                          <MessageSquare className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                          <span>{sch.adminComment}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Admin configuration toolbar inside card */}
                {isAdmin && (
                  <div className="mt-4 pt-3 border-t border-gray-150 flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-150">
                    <span className="text-[9px] font-black uppercase text-indigo-900 tracking-wider">Admin Controls:</span>
                    <div className="flex gap-1">
                      <button
                        onClick={() => handleOpenEdit(sch)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-[9px] font-bold text-indigo-650 bg-white border border-indigo-200 rounded-lg hover:bg-indigo-50 transition-colors cursor-pointer"
                        title="Update details"
                      >
                        <Pencil className="w-3 h-3" /> Edit
                      </button>
                      <button
                        onClick={() => handleRemove(sch)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-[9px] font-bold text-red-650 bg-white border border-red-200 rounded-lg hover:bg-red-50 transition-colors cursor-pointer"
                        title="Delete totally"
                      >
                        <Trash2 className="w-3 h-3" /> Delete
                      </button>
                    </div>
                  </div>
                )}

                {/* Action button apply trigger */}
                <div className="mt-5 pt-4 border-t border-gray-100 flex items-center justify-between">
                  <span className="text-xs text-gray-500 font-semibold flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5 text-emerald-500" /> Free Screening
                  </span>
                  <button
                    onClick={() => handleApplyClick(sch)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm inline-flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    Apply Now <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
